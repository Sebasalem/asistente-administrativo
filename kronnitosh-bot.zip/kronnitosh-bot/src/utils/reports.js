const { formatMoney, formatDate } = require('./helpers');

class ReportSystem {
    constructor(bot) {
        this.bot = bot;
    }

    async generateDailyReport(balance) {
        const today = new Date();
        const todayMovimientos = balance.movimientos.filter(m => 
            new Date(m.fecha).toDateString() === today.toDateString()
        );

        let ingresos = 0;
        let gastos = 0;
        todayMovimientos.forEach(m => {
            if (m.tipo === 'ingreso') ingresos += m.monto;
            if (m.tipo === 'gasto') gastos += m.monto;
        });

        return `
📊 *Reporte Diario* (${formatDate(today)})
━━━━━━━━━━━━━━━
✅ Ingresos: ${formatMoney(ingresos)}
❌ Gastos: ${formatMoney(gastos)}
💰 Balance: ${formatMoney(ingresos - gastos)}
📝 Total movimientos: ${todayMovimientos.length}`;
    }

    async generateMonthlyReport(balance) {
        const now = new Date();
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        const monthMovimientos = balance.movimientos.filter(m => 
            new Date(m.fecha) >= firstDay
        );

        let stats = {
            ingresos: 0,
            gastos: 0,
            alquileres: 0,
            carreras: 0
        };

        monthMovimientos.forEach(m => {
            stats[m.tipo] += m.monto;
        });

        return `
📈 *Reporte Mensual* (${formatDate(firstDay)})
━━━━━━━━━━━━━━━
💰 *Resumen Financiero*
✅ Ingresos: ${formatMoney(stats.ingresos)}
❌ Gastos: ${formatMoney(stats.gastos)}
🏠 Alquileres: ${formatMoney(stats.alquileres)}
🚗 Carreras: ${formatMoney(stats.carreras)}

📊 *Balance General*
💵 Neto: ${formatMoney(balance.balanceNeto)}
🏦 Caja Chica: ${formatMoney(balance.cajaChica.balanceActual)}

📝 *Pendientes*
🏠 Alquileres: ${formatMoney(balance.alquileres.pendienteCobro)}
💳 Deudas: ${formatMoney(balance.deudas.totalPendiente)}`;
    }
}

module.exports = ReportSystem; 