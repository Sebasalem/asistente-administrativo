const fs = require('fs');
const path = require('path');
const Balance = require('../models/Balance');

class BackupSystem {
    constructor(bot) {
        this.bot = bot;
        this.backupPath = path.join(__dirname, '../../backups');
        
        // Crear directorio de backups si no existe
        if (!fs.existsSync(this.backupPath)) {
            fs.mkdirSync(this.backupPath, { recursive: true });
        }
    }

    async createBackup() {
        try {
            const data = await Balance.find({});
            const timestamp = new Date().toISOString().replace(/:/g, '-');
            const filename = `backup_${timestamp}.json`;
            const filepath = path.join(this.backupPath, filename);

            fs.writeFileSync(filepath, JSON.stringify(data, null, 2));
            return filepath;
        } catch (error) {
            console.error('Error al crear backup:', error);
            throw error;
        }
    }

    async sendBackupToAdmin(adminId) {
        try {
            const filepath = await this.createBackup();
            await this.bot.telegram.sendDocument(adminId, {
                source: filepath,
                filename: path.basename(filepath)
            });
            return true;
        } catch (error) {
            console.error('Error al enviar backup:', error);
            return false;
        }
    }
}

module.exports = BackupSystem; 