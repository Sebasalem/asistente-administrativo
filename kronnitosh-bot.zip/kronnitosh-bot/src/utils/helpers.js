const moment = require('moment');
const Decimal = require('decimal.js');

// Formateo de moneda
const formatMoney = (amount) => {
    if (!amount) return '$0.00';
    const decimal = new Decimal(amount);
    return `$${decimal.toFixed(2)}`;
};

// Formateo de fecha
const formatDate = (date) => {
    if (!date) return '';
    return moment(date).format('DD/MM/YYYY');
};

// Validación de monto
const validateMonto = (monto) => {
    if (!monto || isNaN(monto)) return false;
    const amount = new Decimal(monto);
    return amount.greaterThan(0);
};

// Validación de fecha
const validateDate = (date) => {
    return moment(date, 'DD/MM/YYYY', true).isValid();
};

module.exports = {
    formatMoney,
    formatDate,
    validateMonto,
    validateDate
}; 