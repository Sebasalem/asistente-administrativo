const { BOT_ADMINS } = require('../config/config');

class StatusNotifier {
    constructor(bot) {
        this.bot = bot;
        this.lastStatus = null;
        this.subscribers = new Set();
    }

    // Añadir un usuario a las notificaciones
    addSubscriber(userId) {
        this.subscribers.add(userId.toString());
    }

    // Remover un usuario de las notificaciones
    removeSubscriber(userId) {
        this.subscribers.delete(userId.toString());
    }

    // Notificar cambio de estado
    async notifyStatusChange(status, error = null) {
        if (status === this.lastStatus) return; // Evitar notificaciones duplicadas
        
        this.lastStatus = status;
        
        let message = '';
        switch(status) {
            case 'connected':
                message = '✅ Base de datos conectada y funcionando correctamente';
                break;
            case 'disconnected':
                message = '❌ Base de datos desconectada\n⚠️ Algunas funciones podrían no estar disponibles';
                break;
            case 'connecting':
                message = '🔄 Intentando conectar a la base de datos...';
                break;
            case 'error':
                message = `❌ Error en la base de datos:\n${error?.message || 'Error desconocido'}`;
                break;
        }

        // Notificar a todos los suscriptores
        for (const userId of this.subscribers) {
            try {
                await this.bot.telegram.sendMessage(userId, message);
            } catch (error) {
                console.error(`Error notificando a ${userId}:`, error);
            }
        }

        // Notificar a admins con más detalles
        if (status === 'error') {
            const adminMessage = `
🔴 *Error en Base de Datos*
━━━━━━━━━━━━━━━
⚠️ Error: ${error?.message}
📄 Stack: ${error?.stack}
⏰ Hora: ${new Date().toISOString()}`;

            for (const adminId of BOT_ADMINS) {
                try {
                    await this.bot.telegram.sendMessage(adminId, adminMessage, {
                        parse_mode: 'Markdown'
                    });
                } catch (err) {
                    console.error(`Error notificando a admin ${adminId}:`, err);
                }
            }
        }
    }
}

module.exports = StatusNotifier; 