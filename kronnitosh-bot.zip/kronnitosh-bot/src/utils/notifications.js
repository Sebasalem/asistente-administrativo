class NotificationSystem {
    constructor(bot) {
        this.bot = bot;
        this.notifications = new Map();
    }

    async sendNotification(userId, message, options = {}) {
        try {
            const result = await this.bot.telegram.sendMessage(userId, message, {
                parse_mode: 'Markdown',
                ...options
            });
            return result;
        } catch (error) {
            console.error('Error al enviar notificación:', error);
            return null;
        }
    }

    async scheduleNotification(userId, message, date) {
        const now = new Date();
        const scheduleDate = new Date(date);
        const timeout = scheduleDate.getTime() - now.getTime();

        if (timeout <= 0) return;

        const timer = setTimeout(async () => {
            await this.sendNotification(userId, message);
            this.notifications.delete(userId);
        }, timeout);

        this.notifications.set(userId, timer);
    }

    cancelNotification(userId) {
        const timer = this.notifications.get(userId);
        if (timer) {
            clearTimeout(timer);
            this.notifications.delete(userId);
            return true;
        }
        return false;
    }
}

module.exports = NotificationSystem; 