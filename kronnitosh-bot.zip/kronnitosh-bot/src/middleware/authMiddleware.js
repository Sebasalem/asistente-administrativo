// Middleware para verificar si el usuario es root
const config = require('../config');

// Middleware para verificar si el usuario es root
const isRoot = async (ctx, next) => {
    const userId = ctx.from.id.toString();
    
    if (userId !== config.bot.rootId) {
        console.log(`❌ Acceso denegado para usuario ${userId}`);
        return ctx.reply('⛔ No tienes permisos para ejecutar este comando.');
    }

    return next();
};

// Middleware para verificar permisos básicos
const hasPermission = async (ctx, next) => {
    const userId = ctx.from.id.toString();
    
    // En grupos, solo procesar comandos si es necesario
    if (ctx.chat.type !== 'private') {
        // Puedes agregar lógica específica para grupos aquí
        console.log(`Comando ejecutado en grupo por ${userId}`);
    }

    return next();
};

// Middleware para manejar comandos en grupos
const groupCommandHandler = async (ctx, next) => {
    if (ctx.chat.type !== 'private') {
        const isAdminCommand = ctx.message?.text?.startsWith('/');
        const isRootUser = ctx.from.id.toString() === config.bot.rootId;

        if (isAdminCommand && !isRootUser) {
            return; // Ignorar silenciosamente comandos admin de usuarios no root en grupos
        }
    }
    return next();
};

module.exports = {
    isRoot,
    hasPermission,
    groupCommandHandler
}; 