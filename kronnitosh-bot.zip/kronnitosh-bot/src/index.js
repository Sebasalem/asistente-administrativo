require('dotenv').config();
const { Telegraf } = require('telegraf');
const mongoose = require('mongoose');
const express = require('express');
const winston = require('winston');
const SystemMonitor = require('./services/monitor');

// Configuración unificada
const config = {
    bot: {
        token: process.env.TELEGRAM_BOT_TOKEN,
        rootId: process.env.ROOT_ID
    },
    db: {
        uri: process.env.MONGODB_URI,
        options: {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }
    },
    server: {
        port: process.env.PORT || 3000,
        host: process.env.HOST || 'localhost'
    }
};

// Logger centralizado
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.simple()
    ),
    transports: [new winston.transports.Console()]
});

class Application {
    constructor() {
        this.bot = new Telegraf(config.bot.token);
        this.monitor = new SystemMonitor(this.bot, config.bot.rootId);
        this.app = express();
        this.setupExpress();
        this.setupBotCommands();
        this.handleShutdown();
    }

    setupExpress() {
        this.app.use(express.json());
        this.app.get('/health', (_, res) => res.json({ status: 'healthy' }));
    }

    setupBotCommands() {
        // Comando start
        this.bot.command('start', (ctx) => {
            const isAdmin = ctx.from.id.toString() === config.bot.rootId;
            ctx.reply(isAdmin ? '¡Bienvenido Administrador! 🚀' : '¡Bienvenido! 👋');
        });

        // Comando status (solo admin)
        this.bot.command('status', async (ctx) => {
            if (ctx.from.id.toString() === config.bot.rootId) {
                await this.monitor.sendStatusToRoot();
            }
        });

        // Manejadores de botones
        this.bot.action('refresh_status', async (ctx) => {
            if (ctx.from.id.toString() === config.bot.rootId) {
                await ctx.answerCbQuery('Actualizando estado...');
                await this.monitor.sendStatusToRoot();
            }
        });

        this.bot.action('show_details', async (ctx) => {
            if (ctx.from.id.toString() === config.bot.rootId) {
                const status = await this.monitor.checkStatus();
                await ctx.answerCbQuery();
                await this.monitor.sendDetailedStatus(ctx);
            }
        });

        this.bot.action('restart_services', async (ctx) => {
            if (ctx.from.id.toString() === config.bot.rootId) {
                await this.monitor.handleServiceRestart(ctx);
            }
        });

        // Comando help
        this.bot.command('help', (ctx) => {
            const isAdmin = ctx.from.id.toString() === config.bot.rootId;
            const commands = [
                '/start - Iniciar bot',
                '/help - Ver comandos disponibles'
            ];

            if (isAdmin) {
                commands.push(
                    '/status - Ver estado del sistema',
                    '/admin - Panel de administración'
                );
            }

            ctx.reply('Comandos disponibles:\n' + commands.join('\n'));
        });
    }

    async initialize() {
        try {
            // Conectar DB
            await mongoose.connect(config.db.uri, config.db.options);
            logger.info('✅ Base de datos conectada');

            // Iniciar servidor Express
            this.app.listen(config.server.port, config.server.host, () => {
                logger.info(`✅ Servidor API iniciado en ${config.server.host}:${config.server.port}`);
            });

            // Iniciar bot
            await this.bot.launch();
            logger.info('✅ Bot iniciado');

            // Notificar al administrador
            await this.monitor.sendStatusToRoot();

        } catch (error) {
            logger.error('❌ Error de inicialización:', error);
            process.exit(1);
        }
    }

    handleShutdown() {
        const shutdown = async () => {
            logger.info('🛑 Iniciando apagado seguro...');
            await this.bot.stop();
            await mongoose.disconnect();
            process.exit(0);
        };

        process.once('SIGINT', shutdown);
        process.once('SIGTERM', shutdown);
    }
}

// Iniciar aplicación
const app = new Application();
app.initialize().catch(error => {
    logger.error('Error fatal:', error);
    process.exit(1);
}); 