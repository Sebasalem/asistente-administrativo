const { connectDB, logger } = require('../database/connection');

async function setupDatabase() {
  try {
    await connectDB();
    
    // Aquí puedes agregar la creación de índices o configuraciones iniciales
    logger.info('Configuración inicial de la base de datos completada');
    
  } catch (error) {
    logger.error('Error durante la configuración de la base de datos:', error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

setupDatabase(); 