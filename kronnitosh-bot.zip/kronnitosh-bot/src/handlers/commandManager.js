class CommandManager {
    constructor(bot) {
        this.bot = bot;
        this.commands = new Map();
    }

    register(command, handler, middleware = []) {
        this.commands.set(command, { handler, middleware });
        this.bot.command(command, ...middleware, handler);
    }

    registerBatch(commands) {
        Object.entries(commands).forEach(([command, config]) => {
            this.register(command, config.handler, config.middleware || []);
        });
    }

    getCommandList() {
        return Array.from(this.commands.entries()).map(([command, config]) => ({
            command,
            description: config.description || ''
        }));
    }
}

module.exports = CommandManager; 