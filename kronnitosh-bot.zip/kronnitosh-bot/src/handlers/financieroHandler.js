const Balance = require('../models/Balance');

async function handleIngreso(ctx) {
    try {
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('❌ Formato incorrecto. Usa: /ingreso [monto] [descripción]');
        }

        const monto = parseFloat(args[1]);
        const descripcion = args.slice(2).join(' ');

        if (isNaN(monto) || monto <= 0) {
            return ctx.reply('❌ El monto debe ser un número positivo');
        }

        let balance = await Balance.findOne({ userId: ctx.from.id });
        if (!balance) {
            return ctx.reply('❌ Primero debes inicializar tu balance con /inicializar');
        }

        balance.totalIngresos += monto;
        balance.balanceNeto += monto;
        await balance.save();

        ctx.reply(`
✅ Ingreso registrado:
💰 Monto: $${monto}
📝 Descripción: ${descripcion}
📊 Balance actual: $${balance.balanceNeto.toFixed(2)}`);
    } catch (error) {
        console.error(error);
        ctx.reply('❌ Error al registrar el ingreso');
    }
}

async function handleGasto(ctx) {
    try {
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('❌ Uso correcto: /gasto <monto> <descripción>');
        }

        const monto = parseFloat(args[1]);
        const descripcion = args.slice(2).join(' ');

        if (isNaN(monto) || monto <= 0) {
            return ctx.reply('❌ El monto debe ser un número positivo');
        }

        let balance = await Balance.findOne({ userId: ctx.from.id.toString() });
        if (!balance) {
            balance = new Balance({
                userId: ctx.from.id.toString(),
                totalGastos: 0,
                totalIngresos: 0,
                balanceNeto: 0
            });
        }

        // Actualizar balance
        balance.totalGastos += monto;
        balance.balanceNeto -= monto;
        balance.movimientos.push({
            tipo: 'gasto',
            monto: monto,
            descripcion: descripcion,
            fecha: new Date()
        });

        await balance.save();

        ctx.reply(`
✅ Gasto Registrado
━━━━━━━━━━━━━━━
💸 Monto: $${monto.toFixed(2)}
📝 Descripción: ${descripcion}
💰 Balance actual: $${balance.balanceNeto.toFixed(2)}
        `);
    } catch (error) {
        console.error('Error al registrar gasto:', error);
        ctx.reply('❌ Error al registrar el gasto. Intenta nuevamente.');
    }
}

module.exports = {
    handleIngreso,
    handleGasto
}; 