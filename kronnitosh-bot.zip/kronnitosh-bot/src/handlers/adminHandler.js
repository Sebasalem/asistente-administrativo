const BackupSystem = require('../utils/backup');
const NotificationSystem = require('../utils/notifications');
const ReportSystem = require('../utils/reports');
const { BOT_ADMINS } = require('../config/config');

class AdminHandler {
    constructor(bot) {
        this.bot = bot;
        this.backupSystem = new BackupSystem(bot);
        this.notificationSystem = new NotificationSystem(bot);
        this.reportSystem = new ReportSystem(bot);
    }

    isAdmin(userId) {
        return BOT_ADMINS.includes(userId.toString());
    }

    setupCommands() {
        // Comando de backup
        this.bot.command('backup', async (ctx) => {
            if (!this.isAdmin(ctx.from.id)) {
                return ctx.reply('❌ Comando solo para administradores');
            }

            try {
                await ctx.reply('🔄 Creando backup...');
                const success = await this.backupSystem.sendBackupToAdmin(ctx.from.id);
                if (success) {
                    ctx.reply('✅ Backup enviado correctamente');
                } else {
                    ctx.reply('❌ Error al crear el backup');
                }
            } catch (error) {
                console.error('Error en comando backup:', error);
                ctx.reply('❌ Error al procesar el backup');
            }
        });

        // Comando de broadcast
        this.bot.command('broadcast', async (ctx) => {
            if (!this.isAdmin(ctx.from.id)) {
                return ctx.reply('❌ Comando solo para administradores');
            }

            const message = ctx.message.text.split('/broadcast ')[1];
            if (!message) {
                return ctx.reply('❌ Uso: /broadcast [mensaje]');
            }

            try {
                const users = await Balance.distinct('userId');
                let sent = 0;
                for (const userId of users) {
                    try {
                        await this.notificationSystem.sendNotification(userId, message);
                        sent++;
                    } catch (error) {
                        console.error(`Error enviando a ${userId}:`, error);
                    }
                }
                ctx.reply(`✅ Mensaje enviado a ${sent} usuarios`);
            } catch (error) {
                console.error('Error en broadcast:', error);
                ctx.reply('❌ Error al enviar mensajes');
            }
        });

        // Comando de estadísticas
        this.bot.command('stats', async (ctx) => {
            if (!this.isAdmin(ctx.from.id)) {
                return ctx.reply('❌ Comando solo para administradores');
            }

            try {
                const totalUsers = await Balance.countDocuments();
                const stats = await Balance.aggregate([
                    {
                        $group: {
                            _id: null,
                            totalIngresos: { $sum: '$totalIngresos' },
                            totalGastos: { $sum: '$totalGastos' },
                            totalAlquileres: { $sum: '$alquileres.totalMensual' },
                            totalDeudas: { $sum: '$deudas.totalPendiente' }
                        }
                    }
                ]);

                const mensaje = `
📊 *Estadísticas Globales*
━━━━━━━━━━━━━━━
👥 Usuarios totales: ${totalUsers}
💰 Ingresos totales: ${formatMoney(stats[0]?.totalIngresos || 0)}
📉 Gastos totales: ${formatMoney(stats[0]?.totalGastos || 0)}
🏠 Alquileres activos: ${formatMoney(stats[0]?.totalAlquileres || 0)}
💳 Deudas pendientes: ${formatMoney(stats[0]?.totalDeudas || 0)}`;

                await ctx.replyWithMarkdown(mensaje);
            } catch (error) {
                console.error('Error en stats:', error);
                ctx.reply('❌ Error al obtener estadísticas');
            }
        });
    }
}

module.exports = AdminHandler; 