const TaxReport = require('../models/TaxReport');
const Transaction = require('../models/Transaction');
const { formatMoney, formatDate } = require('../utils/helpers');

class TaxHandler {
    constructor(bot) {
        this.bot = bot;
    }

    async generateTaxReport(ctx, periodo = 'mensual') {
        try {
            const userId = ctx.from.id.toString();
            const fecha = new Date();
            
            // Calcular rango de fechas
            let startDate, endDate;
            if (periodo === 'mensual') {
                startDate = new Date(fecha.getFullYear(), fecha.getMonth(), 1);
                endDate = new Date(fecha.getFullYear(), fecha.getMonth() + 1, 0);
            } else if (periodo === 'trimestral') {
                const trimestre = Math.floor(fecha.getMonth() / 3);
                startDate = new Date(fecha.getFullYear(), trimestre * 3, 1);
                endDate = new Date(fecha.getFullYear(), (trimestre + 1) * 3, 0);
            }

            // Obtener transacciones
            const transactions = await Transaction.aggregate([
                {
                    $match: {
                        userId,
                        fecha: { $gte: startDate, $lte: endDate }
                    }
                },
                {
                    $group: {
                        _id: '$tipo',
                        total: { $sum: '$monto' },
                        iva: { $sum: '$impuestos.iva' }
                    }
                }
            ]);

            // Crear reporte fiscal
            const report = new TaxReport({
                userId,
                año: fecha.getFullYear(),
                periodo,
                ingresos: {
                    brutos: transactions.find(t => t._id === 'ingreso')?.total || 0,
                    deducciones: transactions.find(t => t._id === 'egreso')?.total || 0
                },
                impuestos: {
                    iva: {
                        cobrado: transactions.find(t => t._id === 'ingreso')?.iva || 0,
                        pagado: transactions.find(t => t._id === 'egreso')?.iva || 0
                    }
                }
            });

            await report.save();

            ctx.reply(`
📊 Reporte Fiscal ${periodo.toUpperCase()}
━━━━━━━━━━━━━━━
📅 Período: ${formatDate(startDate)} - ${formatDate(endDate)}

💰 INGRESOS:
• Brutos: ${formatMoney(report.ingresos.brutos)}
• Deducciones: ${formatMoney(report.ingresos.deducciones)}
• Netos: ${formatMoney(report.ingresos.brutos - report.ingresos.deducciones)}

🧾 IVA:
• Cobrado: ${formatMoney(report.impuestos.iva.cobrado)}
• Pagado: ${formatMoney(report.impuestos.iva.pagado)}
• Saldo: ${formatMoney(report.impuestos.iva.cobrado - report.impuestos.iva.pagado)}

💡 Usa /tax_detail para ver el desglose completo
            `);
        } catch (error) {
            console.error('Error en reporte fiscal:', error);
            ctx.reply('❌ Error al generar reporte fiscal');
        }
    }
}

module.exports = TaxHandler; 