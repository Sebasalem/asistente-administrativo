const Balance = require('../models/balance');

async function handleAlquilerAdd(ctx) {
    try {
        const args = ctx.message.text.split(' ');
        if (args.length < 3) {
            return ctx.reply('❌ Formato incorrecto. Usa: /alquiler_add [monto] [inquilino]');
        }

        const monto = parseFloat(args[1]);
        const inquilino = args.slice(2).join(' ');

        let balance = await Balance.findOne({ userId: ctx.from.id });
        if (!balance) {
            return ctx.reply('❌ Primero debes inicializar tu balance con /inicializar');
        }

        balance.alquileres.lista.push({
            inquilino,
            monto,
            fechaPago: new Date()
        });

        balance.alquileres.totalMensual += monto;
        balance.alquileres.pendienteCobro += monto;
        await balance.save();

        ctx.reply(`
✅ Alquiler registrado:
👤 Inquilino: ${inquilino}
💰 Monto mensual: $${monto}
📊 Total pendiente: $${balance.alquileres.pendienteCobro.toFixed(2)}`);
    } catch (error) {
        console.error(error);
        ctx.reply('❌ Error al registrar alquiler');
    }
}

module.exports = {
    handleAlquilerAdd
}; 