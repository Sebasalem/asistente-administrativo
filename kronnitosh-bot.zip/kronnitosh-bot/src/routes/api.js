const express = require('express');
const router = express.Router();

// Estado del sistema
router.get('/status', async (req, res) => {
    try {
        const status = {
            uptime: process.uptime(),
            timestamp: Date.now(),
            status: 'OK'
        };
        res.json(status);
    } catch (error) {
        console.error('Error en /status:', error);
        res.status(500).json({ error: 'Error al obtener estado del sistema' });
    }
});

// Estadísticas
router.get('/stats', async (req, res) => {
    try {
        const stats = {
            users: 0,
            messages: 0,
            lastUpdate: new Date()
        };
        res.json(stats);
    } catch (error) {
        console.error('Error en /stats:', error);
        res.status(500).json({ error: 'Error al obtener estadísticas' });
    }
});

// Backup
router.post('/backup', async (req, res) => {
    try {
        const backup = await backupService.createBackup();
        res.json(backup);
    } catch (error) {
        res.status(500).json({ error: 'Error al crear backup' });
    }
});

module.exports = router; 