const presentation = {
    welcome: `
🤖 Kronnitosh Bot - Sistema de Gestión
━━━━━━━━━━━━━━━━━━━━━━━━━━

Sistema profesional para gestión de:
• 💰 Finanzas y Balances
• 🏠 Alquileres
• 🚗 Carreras
• 💳 Deudas

Comandos principales:
/start - Iniciar sistema
/ayuda - Ver comandos disponibles
/estado - Ver estado actual

Para soporte: /soporte
    `,
    
    adminWelcome: `
🎛️ Panel de Administración
━━━━━━━━━━━━━━━

🔧 Sistema:
• /estado - Estado del sistema
• /logs - Ver registros
• /backup - Gestión de backups

⚙️ Gestión:
• /usuarios - Gestionar usuarios
• /config - Configuración
• /stats - Estadísticas

📊 Reportes:
• /reporte - Generar reporte
• /balance - Balance general
    `,

    help: {
        user: `
📱 Comandos Disponibles
━━━━━━━━━━━━━━━

💰 Gestión Financiera:
• /balance - Balance actual
• /ingreso <monto> - Registrar ingreso
• /gasto <monto> - Registrar gasto

📊 Reportes:
• /resumen - Resumen general
• /diario - Movimientos del día
• /mensual - Reporte mensual

🔧 Utilidades:
• /ayuda - Ver comandos
• /soporte - Solicitar ayuda
• /estado - Ver estado
        `,
        
        admin: `
⚙️ Comandos Administrativos
━━━━━━━━━━━━━━━

🛠️ Sistema:
• /reiniciar - Reiniciar sistema
• /mantenimiento - Modo mantenimiento
• /debug - Modo debug

📊 Gestión:
• /usuarios - Lista de usuarios
• /bloquear <id> - Bloquear usuario
• /desbloquear <id> - Desbloquear usuario

💾 Datos:
• /backup - Crear backup
• /restore - Restaurar backup
• /purgar - Limpiar datos antiguos
        `
    }
};

module.exports = presentation; 