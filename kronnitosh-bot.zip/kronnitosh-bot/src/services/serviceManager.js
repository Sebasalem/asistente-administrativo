const BackupService = require('./backupService');
const FinanceService = require('./financeService');
const NotificationService = require('./notificationService');

class ServiceManager {
    constructor(bot) {
        if (!bot) {
            throw new Error('Bot instance is required for ServiceManager');
        }

        try {
            this.services = {
                backup: new BackupService(bot),
                finance: new FinanceService(),
                notification: new NotificationService(bot)
            };
        } catch (error) {
            console.error('❌ Error creando servicios:', error);
            throw error;
        }
    }

    async initialize() {
        console.log('🔄 Iniciando servicios...');
        
        for (const [name, service] of Object.entries(this.services)) {
            try {
                console.log(`⚙️ Iniciando servicio: ${name}`);
                await service.initialize();
                console.log(`✅ Servicio ${name} iniciado correctamente`);
            } catch (error) {
                console.error(`❌ Error iniciando servicio ${name}:`, error);
                throw error;
            }
        }
        
        console.log('✅ Todos los servicios iniciados correctamente');
    }

    getService(name) {
        const service = this.services[name];
        if (!service) {
            throw new Error(`Servicio '${name}' no encontrado`);
        }
        return service;
    }

    async shutdown() {
        console.log('🔄 Cerrando servicios...');
        for (const [name, service] of Object.entries(this.services)) {
            try {
                if (service.shutdown) {
                    await service.shutdown();
                }
                console.log(`✅ Servicio ${name} cerrado correctamente`);
            } catch (error) {
                console.error(`❌ Error cerrando servicio ${name}:`, error);
            }
        }
    }
}

module.exports = ServiceManager; 