const Backup = require('../models/Backup');

class BackupService {
    constructor(bot) {
        this.bot = bot;
    }

    async initialize() {
        // Inicialización si es necesaria
    }

    async createBackup(userId, type, data) {
        try {
            const backup = new Backup({
                userId,
                dataType: type,
                data,
                deletedBy: userId
            });
            await backup.save();
            return backup;
        } catch (error) {
            console.error('Error creando backup:', error);
            throw error;
        }
    }

    async getBackups(userId) {
        return await Backup.find({ userId }).sort({ deletedAt: -1 });
    }
}

module.exports = BackupService; 