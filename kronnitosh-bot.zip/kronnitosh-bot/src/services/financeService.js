const Balance = require('../models/Balance');

class FinanceService {
    constructor() {
        this.balanceCache = new Map();
    }

    async initialize() {
        try {
            console.log('🔄 Inicializando servicio financiero...');
            // Verificar conexión con la base de datos
            await Balance.findOne();
            console.log('✅ Servicio financiero inicializado');
        } catch (error) {
            console.error('❌ Error inicializando servicio financiero:', error);
            throw error;
        }
    }

    async getBalance(userId) {
        try {
            if (this.balanceCache.has(userId)) {
                return this.balanceCache.get(userId);
            }

            let balance = await Balance.findOne({ userId });
            if (!balance) {
                balance = new Balance({ 
                    userId,
                    totalIngresos: 0,
                    totalGastos: 0,
                    balanceNeto: 0
                });
                await balance.save();
            }

            this.balanceCache.set(userId, balance);
            return balance;
        } catch (error) {
            console.error('Error obteniendo balance:', error);
            throw error;
        }
    }

    async registerTransaction(userId, type, amount, description) {
        try {
            const balance = await this.getBalance(userId);
            
            if (type === 'ingreso') {
                balance.totalIngresos += amount;
                balance.balanceNeto += amount;
            } else if (type === 'gasto') {
                balance.totalGastos += amount;
                balance.balanceNeto -= amount;
            }

            balance.movimientos.push({
                tipo: type,
                monto: amount,
                descripcion: description,
                fecha: new Date()
            });

            await balance.save();
            this.balanceCache.set(userId, balance);
            return balance;
        } catch (error) {
            console.error(`Error registrando ${type}:`, error);
            throw error;
        }
    }

    clearCache(userId) {
        if (userId) {
            this.balanceCache.delete(userId);
        } else {
            this.balanceCache.clear();
        }
    }
}

// Importante: Exportar la clase correctamente
module.exports = FinanceService; 