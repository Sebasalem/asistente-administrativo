const mongoose = require('mongoose');
const os = require('os');

class SystemMonitor {
    constructor(bot, rootId) {
        this.bot = bot;
        this.rootId = rootId;
    }

    async checkStatus() {
        return {
            mongodb: mongoose.connection.readyState === 1,
            server: true,
            timestamp: new Date().toISOString(),
            system: {
                memory: {
                    total: os.totalmem(),
                    free: os.freemem(),
                    used: process.memoryUsage().heapUsed
                },
                uptime: process.uptime(),
                platform: process.platform,
                nodeVersion: process.version
            }
        };
    }

    async sendStatusToRoot() {
        const status = await this.checkStatus();
        
        const statusText = `
🔍 Estado del Sistema:

📊 MongoDB: ${status.mongodb ? '✅ Conectado' : '❌ Desconectado'}
🖥️ Servidor: ${status.server ? '✅ Activo' : '❌ Inactivo'}
🕒 Actualización: ${new Date(status.timestamp).toLocaleString()}
        `.trim();

        const keyboard = {
            inline_keyboard: [
                [
                    { text: '🔄 Actualizar', callback_data: 'refresh_status' },
                    { text: '📊 Detalles', callback_data: 'show_details' }
                ],
                [
                    { text: '🔧 Reiniciar Servicios', callback_data: 'restart_services' }
                ]
            ]
        };

        try {
            await this.bot.telegram.sendMessage(this.rootId, statusText, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        } catch (error) {
            console.error('Error al enviar estado:', error);
        }
    }

    async sendDetailedStatus(ctx) {
        const status = await this.checkStatus();
        const memoryUsedMB = Math.round(status.system.memory.used / 1024 / 1024);
        const memoryTotalGB = Math.round(status.system.memory.total / 1024 / 1024 / 1024);
        
        const details = `
📊 Detalles del Sistema:

MongoDB:
- Estado: ${status.mongodb ? '✅ Conectado' : '❌ Desconectado'}
- Database: ${process.env.MONGODB_URI?.split('/').pop() || 'N/A'}

Servidor:
- Puerto: ${process.env.PORT || 3000}
- Ambiente: ${process.env.NODE_ENV || 'development'}
- Uptime: ${Math.floor(status.system.uptime)} segundos

Sistema:
- Memoria Usada: ${memoryUsedMB}MB
- Memoria Total: ${memoryTotalGB}GB
- Plataforma: ${status.system.platform}
- Node Version: ${status.system.nodeVersion}
        `.trim();

        await ctx.reply(details);
    }

    async handleServiceRestart(ctx) {
        await ctx.answerCbQuery('Reiniciando servicios...');
        await ctx.reply('⚠️ Iniciando reinicio de servicios...');
        
        try {
            await mongoose.disconnect();
            await mongoose.connect(process.env.MONGODB_URI, {
                useNewUrlParser: true,
                useUnifiedTopology: true
            });
            
            await ctx.reply('✅ Servicios reiniciados correctamente');
            await this.sendStatusToRoot();
        } catch (error) {
            await ctx.reply('❌ Error al reiniciar servicios: ' + error.message);
        }
    }
}

module.exports = SystemMonitor; 