class NotificationService {
    constructor(bot) {
        this.bot = bot;
        this.subscribers = new Set();
        this.notificationQueue = [];
        this.isProcessing = false;
    }

    async initialize() {
        try {
            console.log('🔄 Inicializando servicio de notificaciones...');
            // Iniciar el procesamiento de la cola
            this.startQueueProcessing();
            console.log('✅ Servicio de notificaciones inicializado');
        } catch (error) {
            console.error('❌ Error inicializando notificaciones:', error);
            throw error;
        }
    }

    startQueueProcessing() {
        setInterval(() => this.processQueue(), 1000);
    }

    async processQueue() {
        if (this.isProcessing || this.notificationQueue.length === 0) return;

        this.isProcessing = true;
        try {
            const notification = this.notificationQueue.shift();
            await this.bot.telegram.sendMessage(
                notification.userId,
                notification.message,
                notification.options
            );
        } catch (error) {
            console.error('Error procesando notificación:', error);
        } finally {
            this.isProcessing = false;
        }
    }

    queueNotification(userId, message, options = {}) {
        this.notificationQueue.push({ userId, message, options });
    }

    async sendNotification(userId, message, options = {}) {
        try {
            return await this.bot.telegram.sendMessage(userId, message, {
                parse_mode: 'Markdown',
                ...options
            });
        } catch (error) {
            console.error('Error enviando notificación:', error);
            // Encolar para reintentar
            this.queueNotification(userId, message, options);
            throw error;
        }
    }

    subscribe(userId) {
        this.subscribers.add(userId.toString());
    }

    unsubscribe(userId) {
        this.subscribers.delete(userId.toString());
    }

    async broadcast(message, filter = () => true) {
        const errors = [];
        const promises = Array.from(this.subscribers)
            .filter(filter)
            .map(async (userId) => {
                try {
                    await this.sendNotification(userId, message);
                } catch (error) {
                    errors.push({ userId, error });
                }
            });

        await Promise.all(promises);
        return errors;
    }
}

// Importante: Exportar la clase correctamente
module.exports = NotificationService; 