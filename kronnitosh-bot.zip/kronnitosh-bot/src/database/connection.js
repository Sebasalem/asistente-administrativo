const mongoose = require('mongoose');
const config = require('../config/config');
const winston = require('winston');

const logger = winston.createLogger({
  level: config.debug ? 'debug' : 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console()
  ]
});

async function connectDB() {
  try {
    await mongoose.connect(config.mongodb.uri, config.mongodb.options);
    logger.info('Conexión a MongoDB establecida correctamente');
  } catch (error) {
    logger.error('Error al conectar con MongoDB:', error);
    process.exit(1);
  }
}

mongoose.connection.on('error', (err) => {
  logger.error('Error de MongoDB:', err);
});

mongoose.connection.on('disconnected', () => {
  logger.warn('MongoDB desconectado. Intentando reconectar...');
});

process.on('SIGINT', async () => {
  await mongoose.connection.close();
  logger.info('Conexión a MongoDB cerrada por finalización de la aplicación');
  process.exit(0);
});

module.exports = { connectDB, logger }; 