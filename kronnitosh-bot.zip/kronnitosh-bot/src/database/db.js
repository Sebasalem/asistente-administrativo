const mongoose = require('mongoose');
const config = require('../config');

class Database {
    constructor() {
        this.connection = null;
        this.isConnected = false;
    }

    async connect() {
        try {
            this.connection = await mongoose.connect(config.db.uri, config.db.options);
            this.isConnected = true;
            console.log('✅ Conectado a MongoDB');
            this.setupListeners();
            return true;
        } catch (error) {
            console.error('❌ Error de conexión:', error);
            return false;
        }
    }

    setupListeners() {
        mongoose.connection.on('disconnected', () => {
            this.isConnected = false;
            console.log('🔄 MongoDB desconectado. Intentando reconectar...');
            setTimeout(() => this.connect(), 5000);
        });

        mongoose.connection.on('error', (error) => {
            console.error('❌ Error de MongoDB:', error);
        });
    }

    async disconnect() {
        if (this.connection) {
            await mongoose.connection.close();
            this.isConnected = false;
            console.log('✅ Desconexión exitosa de MongoDB');
        }
    }
}

module.exports = new Database(); 