const SystemMonitor = require('./services/monitor');
const mongoose = require('mongoose');

module.exports = (bot) => {
    const monitor = new SystemMonitor(bot, process.env.ROOT_ID);

    // Comandos de admin
    bot.command('admin', (ctx) => {
        if (ctx.from.id.toString() === process.env.ROOT_ID) {
            ctx.reply('Panel de administración');
        }
    });

    // Comando de estado del sistema (solo para root)
    bot.command('status', async (ctx) => {
        if (ctx.from.id.toString() === process.env.ROOT_ID) {
            await monitor.sendStatusToRoot();
        }
    });

    // Manejador de callbacks para los botones
    bot.action('refresh_status', async (ctx) => {
        if (ctx.from.id.toString() === process.env.ROOT_ID) {
            await ctx.answerCbQuery('Actualizando estado...');
            await monitor.sendStatusToRoot();
        }
    });

    bot.action('show_details', async (ctx) => {
        if (ctx.from.id.toString() === process.env.ROOT_ID) {
            const status = await monitor.checkStatus();
            const details = `
📊 Detalles del Sistema:

MongoDB:
- Estado: ${status.mongodb ? 'Conectado' : 'Desconectado'}
- Database: ${process.env.MONGODB_URI.split('/').pop()}

Servidor:
- Puerto: ${process.env.PORT || 3000}
- Ambiente: ${process.env.NODE_ENV || 'development'}
- Uptime: ${Math.floor(process.uptime())} segundos

Sistema:
- Memoria: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB
- Node Version: ${process.version}
            `;
            
            await ctx.answerCbQuery();
            await ctx.reply(details);
        }
    });

    bot.action('restart_services', async (ctx) => {
        if (ctx.from.id.toString() === process.env.ROOT_ID) {
            await ctx.answerCbQuery('Reiniciando servicios...');
            await ctx.reply('⚠️ Iniciando reinicio de servicios...');
            
            try {
                // Aquí puedes agregar la lógica de reinicio
                await mongoose.disconnect();
                await mongoose.connect(process.env.MONGODB_URI);
                await ctx.reply('✅ Servicios reiniciados correctamente');
                await monitor.sendStatusToRoot();
            } catch (error) {
                await ctx.reply('❌ Error al reiniciar servicios: ' + error.message);
            }
        }
    });

    // Comandos de usuario
    bot.command('help', (ctx) => {
        const isAdmin = ctx.from.id.toString() === process.env.ROOT_ID;
        const commands = [
            '/start - Iniciar bot',
            '/help - Ver comandos disponibles'
        ];

        if (isAdmin) {
            commands.push(
                '/status - Ver estado del sistema',
                '/admin - Panel de administración'
            );
        }

        ctx.reply('Comandos disponibles:\n' + commands.join('\n'));
    });

    // Otros comandos...
}; 