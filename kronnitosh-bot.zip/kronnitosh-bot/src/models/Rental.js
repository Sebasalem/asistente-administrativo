const mongoose = require('mongoose');

const rentalSchema = new mongoose.Schema({
    nombre: {
        type: String,
        required: true
    },
    monto: {
        type: Number,
        required: true
    },
    ultimoPago: {
        type: Date,
        default: null
    },
    estado: {
        type: String,
        enum: ['al_dia', 'pendiente'],
        default: 'pendiente'
    },
    historialPagos: [{
        fecha: Date,
        monto: Number,
        descripcion: String
    }],
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Rental', rentalSchema); 