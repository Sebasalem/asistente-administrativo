const mongoose = require('mongoose');

const presupuestoSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        index: true
    },
    mes: {
        type: Date,
        required: true
    },
    categorias: [{
        nombre: String,
        tipo: {
            type: String,
            enum: ['ingreso', 'egreso']
        },
        presupuestado: Number,
        actual: {
            type: Number,
            default: 0
        }
    }],
    metas: [{
        descripcion: String,
        monto: Number,
        fecha_objetivo: Date,
        progreso: {
            type: Number,
            default: 0
        }
    }],
    notas: String,
    estado: {
        type: String,
        enum: ['activo', 'cerrado'],
        default: 'activo'
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Budget', presupuestoSchema); 