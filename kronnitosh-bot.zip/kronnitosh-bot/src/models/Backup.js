const mongoose = require('mongoose');

const backupSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    dataType: {
        type: String,
        required: true,
        enum: ['user', 'function', 'data', 'shutdown', 'system']
    },
    data: {
        type: mongoose.Schema.Types.Mixed,
        required: true
    },
    deletedAt: {
        type: Date,
        default: Date.now
    },
    deletedBy: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model('Backup', backupSchema); 