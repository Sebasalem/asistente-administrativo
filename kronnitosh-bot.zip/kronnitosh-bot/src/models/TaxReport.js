const mongoose = require('mongoose');

const taxReportSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        index: true
    },
    año: {
        type: Number,
        required: true
    },
    periodo: {
        type: String,
        enum: ['mensual', 'trimestral', 'anual'],
        required: true
    },
    ingresos: {
        brutos: Number,
        deducciones: Number,
        netos: Number
    },
    impuestos: {
        iva: {
            cobrado: Number,
            pagado: Number,
            saldo: Number
        },
        renta: {
            base_imponible: Number,
            retenido: Number,
            a_pagar: Number
        }
    },
    estado: {
        type: String,
        enum: ['pendiente', 'presentado', 'pagado'],
        default: 'pendiente'
    },
    documentos: [{
        tipo: String,
        numero: String,
        fecha: Date,
        monto: Number
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('TaxReport', taxReportSchema); 