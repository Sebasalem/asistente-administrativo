const mongoose = require('mongoose');

const debtorSchema = new mongoose.Schema({
    id: {
        type: Number,
        required: true,
        unique: true
    },
    nombre: {
        type: String,
        required: true
    },
    monto: {
        type: Number,
        required: true
    },
    concepto: {
        type: String,
        required: true
    },
    fecha: {
        type: Date,
        required: true
    },
    estado: {
        type: String,
        enum: ['pendiente', 'pagado'],
        default: 'pendiente'
    }
});

module.exports = mongoose.model('Debtor', debtorSchema); 