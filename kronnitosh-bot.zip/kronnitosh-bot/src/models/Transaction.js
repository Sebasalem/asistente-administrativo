const mongoose = require('mongoose');

const CATEGORIAS_INGRESO = [
    'salario',
    'inversiones',
    'alquileres',
    'ventas',
    'comisiones',
    'dividendos',
    'reembolsos',
    'otros_ingresos'
];

const CATEGORIAS_EGRESO = [
    'alimentos',
    'transporte',
    'servicios',
    'alquiler',
    'educacion',
    'salud',
    'entretenimiento',
    'impuestos',
    'seguros',
    'mantenimiento',
    'otros_gastos'
];

const CATEGORIAS_ACTIVO = [
    'inmuebles',
    'vehiculos',
    'equipos',
    'inversiones',
    'cuentas_por_cobrar',
    'inventario',
    'otros_activos'
];

const CATEGORIAS_PASIVO = [
    'prestamos',
    'hipotecas',
    'tarjetas_credito',
    'impuestos_por_pagar',
    'servicios_por_pagar',
    'otros_pasivos'
];

const transactionSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        index: true
    },
    tipo: {
        type: String,
        enum: ['ingreso', 'egreso', 'activo', 'pasivo'],
        required: true
    },
    categoria: {
        type: String,
        required: true,
        validate: {
            validator: function(v) {
                switch(this.tipo) {
                    case 'ingreso': return CATEGORIAS_INGRESO.includes(v);
                    case 'egreso': return CATEGORIAS_EGRESO.includes(v);
                    case 'activo': return CATEGORIAS_ACTIVO.includes(v);
                    case 'pasivo': return CATEGORIAS_PASIVO.includes(v);
                    default: return false;
                }
            },
            message: 'Categoría inválida para el tipo de transacción'
        }
    },
    monto: {
        type: Number,
        required: true,
        min: 0
    },
    descripcion: {
        type: String,
        required: true
    },
    fecha: {
        type: Date,
        default: Date.now,
        index: true
    },
    comprobante: {
        numero: String,
        tipo: {
            type: String,
            enum: ['factura', 'recibo', 'ticket', 'otro']
        },
        imagen: String
    },
    estado: {
        type: String,
        enum: ['pendiente', 'completado', 'anulado'],
        default: 'completado'
    },
    metodo_pago: {
        type: String,
        enum: ['efectivo', 'transferencia', 'tarjeta', 'otro'],
        required: true
    },
    impuestos: {
        iva: {
            type: Number,
            default: 0
        },
        otros: {
            type: Number,
            default: 0
        }
    },
    etiquetas: [String],
    metadata: {
        ubicacion: String,
        notas: String,
        referencia: String
    }
}, {
    timestamps: true
});

// Índices para mejorar el rendimiento
transactionSchema.index({ userId: 1, fecha: -1 });
transactionSchema.index({ userId: 1, tipo: 1, categoria: 1 });

// Métodos estáticos para reportes
transactionSchema.statics.getCategoriasByTipo = function(tipo) {
    switch(tipo) {
        case 'ingreso': return CATEGORIAS_INGRESO;
        case 'egreso': return CATEGORIAS_EGRESO;
        case 'activo': return CATEGORIAS_ACTIVO;
        case 'pasivo': return CATEGORIAS_PASIVO;
        default: return [];
    }
};

module.exports = mongoose.model('Transaction', transactionSchema); 