const mongoose = require('mongoose');

const financeSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    // Balance General
    ingresos: {
        type: Number,
        default: 0
    },
    gastos: {
        type: Number,
        default: 0
    },
    // Caja Chica
    cajaChica: {
        type: Number,
        default: 0
    },
    // Sistema de Carreras
    carreras: {
        disponibles: {
            type: Number,
            default: 0
        },
        balance: {
            type: Number,
            default: 0
        }
    },
    // Sistema de Deudas
    deudas: {
        total: {
            type: Number,
            default: 0
        },
        pendientes: [{
            descripcion: String,
            monto: Number,
            fecha: Date
        }]
    },
    // Activos y Pasivos
    activos: {
        type: Number,
        default: 0
    },
    pasivos: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Finance', financeSchema); 