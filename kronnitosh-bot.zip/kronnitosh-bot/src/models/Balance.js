const mongoose = require('mongoose');

const movimientoSchema = new mongoose.Schema({
    tipo: {
        type: String,
        enum: ['ingreso', 'gasto', 'carrera', 'alquiler'],
        required: true
    },
    monto: {
        type: Number,
        required: true
    },
    descripcion: String,
    fecha: {
        type: Date,
        default: Date.now
    }
});

const alquilerSchema = new mongoose.Schema({
    inquilino: String,
    monto: Number,
    estado: {
        type: String,
        enum: ['pendiente', 'pagado'],
        default: 'pendiente'
    },
    fechaRegistro: {
        type: Date,
        default: Date.now
    },
    fechaPago: Date
});

const balanceSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        unique: true
    },
    totalIngresos: {
        type: Number,
        default: 0
    },
    totalGastos: {
        type: Number,
        default: 0
    },
    balanceNeto: {
        type: Number,
        default: 0
    },
    cajaChica: {
        balanceActual: {
            type: Number,
            default: 0
        },
        movimientos: [movimientoSchema]
    },
    alquileres: {
        lista: [alquilerSchema],
        totalMensual: {
            type: Number,
            default: 0
        },
        pendienteCobro: {
            type: Number,
            default: 0
        }
    },
    carreras: {
        disponibles: {
            type: Number,
            default: 0
        },
        balance: {
            type: Number,
            default: 0
        },
        historial: [movimientoSchema]
    },
    deudas: {
        totalPendiente: {
            type: Number,
            default: 0
        },
        lista: [{
            descripcion: String,
            monto: Number,
            estado: {
                type: String,
                enum: ['pendiente', 'pagado'],
                default: 'pendiente'
            },
            fecha: {
                type: Date,
                default: Date.now
            }
        }]
    },
    movimientos: [movimientoSchema]
}, {
    timestamps: true
});

module.exports = mongoose.models.Balance || mongoose.model('Balance', balanceSchema); 