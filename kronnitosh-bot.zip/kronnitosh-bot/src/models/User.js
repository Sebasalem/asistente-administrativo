const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    telegramId: {
        type: String,
        required: true,
        unique: true
    },
    username: String,
    fullName: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    documentId: {
        type: String,
        required: true,
        unique: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    lastActivity: Date
}, {
    timestamps: true
});

// Verificar si el modelo ya existe antes de definirlo
const User = mongoose.models.User || mongoose.model('User', userSchema);

module.exports = User; 