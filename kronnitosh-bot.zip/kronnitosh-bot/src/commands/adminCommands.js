const mongoose = require('mongoose');
const User = require('../models/User');
const Backup = require('../models/Backup');
const Balance = require('../models/Balance');
const { formatMoney } = require('../utils/helpers');
const config = require('../config');

const adminCommands = (bot) => {
    // Comando start
    bot.command('start', async (ctx) => {
        if (ctx.from.id.toString() === process.env.ROOT_ID) {
            ctx.reply(`
🎛️ Panel de Control Root
━━━━━━━━━━━━━━━

🔧 Sistema:
• /start - Panel de Control
• /estado - Ver estado completo
• /ping - Verificar conexión

⚙️ Gestión:
• /reiniciar - Recargar sin reseteo
• /reset - Reseteo completo
• /stop - Detener bot

📊 Monitoreo:
• /stats - Estadísticas
• /backups - Ver backups
• /logs - Ver registros

💡 Tip: Usa /ayuda para más detalles`);
        }
    });

    // Comando estado
    bot.command('estado', async (ctx) => {
        try {
            const stats = {
                users: await User.countDocuments(),
                dbStatus: mongoose.connection.readyState === 1 ? '✅ Conectada' : '❌ Desconectada',
                uptime: process.uptime()
            };
            
            ctx.reply(`
📊 Estado del Sistema
━━━━━━━━━━━━━━━
👥 Usuarios: ${stats.users}
📡 Base de datos: ${stats.dbStatus}
⏱️ Uptime: ${Math.floor(stats.uptime / 3600)}h ${Math.floor((stats.uptime % 3600) / 60)}m`);
        } catch (error) {
            console.error('Error en comando estado:', error);
            ctx.reply('❌ Error al obtener estado del sistema');
        }
    });

    // Comando ping
    bot.command('ping', async (ctx) => {
        const start = Date.now();
        try {
            await mongoose.connection.db.admin().ping();
            const dbTime = Date.now() - start;
            ctx.reply(`
📡 Diagnóstico
━━━━━━━━━━━━━━━
🤖 Bot: ✅ Funcionando
📊 DB: ✅ Conectada (${dbTime}ms)
🔄 API: ✅ Respondiendo`);
        } catch (error) {
            ctx.reply('❌ Error de conexión con la base de datos');
        }
    });

    // Comando reiniciar
    bot.command('reiniciar', async (ctx) => {
        ctx.reply('🔄 Iniciando reinicio del sistema...');
        try {
                    await mongoose.connection.close();
            await mongoose.connect(process.env.MONGODB_URI);
            ctx.reply('✅ Sistema reiniciado correctamente');
        } catch (error) {
            console.error('Error al reiniciar:', error);
            ctx.reply('❌ Error durante el reinicio');
        }
    });

    // Comando stop
    bot.command('stop', async (ctx) => {
        ctx.reply('🛑 Deteniendo el bot...');
        try {
            await mongoose.connection.close();
            process.exit(0);
        } catch (error) {
            console.error('Error al detener:', error);
            ctx.reply('❌ Error al detener el bot');
        }
    });

    // Comando stats
    bot.command('stats', async (ctx) => {
        // Lógica del comando stats
    });

    // Comando backups
    bot.command('backups', async (ctx) => {
        // Lógica del comando backups
    });

    // Comando logs
    bot.command('logs', async (ctx) => {
        // Lógica del comando logs
    });
};

module.exports = adminCommands; 