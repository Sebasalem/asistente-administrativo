const Finance = require('../models/Finance');
const { isRegistered } = require('../middleware/authMiddleware');
const { handleGasto, handleIngreso, handleBalance } = require('../handlers/financieroHandler');

const financeCommands = (bot) => {
    // Comando principal de balance
    bot.command('balance', isRegistered, handleBalance);

    // Comando para agregar ingreso
    bot.command('ingreso', isRegistered, handleIngreso);

    // Comando para registrar gasto
    bot.command('gasto', isRegistered, handleGasto);

    // Comando para gestionar carreras
    bot.command('carrera', async (ctx) => {
        const userId = ctx.from.id.toString();
        const args = ctx.message.text.split(' ');
        const accion = args[1]; // "agregar" o "completar"
        const monto = parseFloat(args[2]);

        if (!accion || (accion === 'completar' && !monto)) {
            return ctx.reply(`
❌ Uso correcto:
/carrera agregar - Agregar nueva carrera
/carrera completar <monto> - Completar carrera con pago
            `);
        }

        try {
            let finance;
            if (accion === 'agregar') {
                finance = await Finance.findOneAndUpdate(
                    { userId },
                    { $inc: { 'carreras.disponibles': 1 } },
                    { upsert: true, new: true }
                );

                ctx.reply(`
✅ Carrera Agregada
━━━━━━━━━━━━━━━
🚗 Carreras disponibles: ${finance.carreras.disponibles}
            `);
            } else if (accion === 'completar') {
                finance = await Finance.findOneAndUpdate(
                    { userId },
                    { 
                        $inc: { 
                            'carreras.disponibles': -1,
                            'carreras.balance': monto,
                            cajaChica: monto
                        }
                    },
                    { upsert: true, new: true }
                );

                ctx.reply(`
✅ Carrera Completada
━━━━━━━━━━━━━━━
💰 Monto: $${monto.toFixed(2)}
🚗 Carreras restantes: ${finance.carreras.disponibles}
💵 Balance de carreras: $${finance.carreras.balance.toFixed(2)}
            `);
            }
        } catch (error) {
            console.error('Error en gestión de carreras:', error);
            ctx.reply('❌ Error al procesar la carrera.');
        }
    });

    // Comando para registrar deuda
    bot.command('deuda', async (ctx) => {
        const userId = ctx.from.id.toString();
        const args = ctx.message.text.split(' ');
        const monto = parseFloat(args[1]);
        const descripcion = args.slice(2).join(' ');

        if (!monto || isNaN(monto) || !descripcion) {
            return ctx.reply('❌ Uso correcto: /deuda <monto> <descripción>');
        }

        try {
            const finance = await Finance.findOneAndUpdate(
                { userId },
                { 
                    $inc: { 'deudas.total': monto },
                    $push: { 
                        'deudas.pendientes': {
                            monto,
                            descripcion,
                            fecha: new Date()
                        }
                    }
                },
                { upsert: true, new: true }
            );

            ctx.reply(`
✅ Deuda Registrada
━━━━━━━━━━━━━━━
💸 Monto: $${monto.toFixed(2)}
📝 Descripción: ${descripcion}
💳 Total deudas: $${finance.deudas.total.toFixed(2)}
            `);
        } catch (error) {
            console.error('Error al registrar deuda:', error);
            ctx.reply('❌ Error al registrar la deuda.');
        }
    });
};

module.exports = financeCommands; 