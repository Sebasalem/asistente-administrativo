const User = require('../models/User');
const Backup = require('../models/Backup');
const config = require('../config');
const { hasPermission } = require('../middleware/authMiddleware');

// Objeto con la documentación detallada de cada comando
const commandHelp = {
    registro: {
        comando: '/registro',
        descripcion: 'Registra un nuevo usuario en el sistema',
        uso: '/registro <nombre> <email> <telefono>',
        ejemplo: '/registro Juan Pérez\njuan@email.com\n+34612345678',
        notas: [
            '• El email debe ser válido',
            '• El teléfono debe incluir código de país',
            '• El nombre debe ser completo'
        ]
    },
    balance: {
        comando: '/balance',
        descripcion: 'Muestra tu balance general actual',
        uso: '/balance',
        ejemplo: '/balance',
        notas: [
            '• Muestra ingresos y gastos',
            '• Incluye balance de caja chica',
            '• Detalla alquileres pendientes'
        ]
    },
    ingreso: {
        comando: '/ingreso',
        descripcion: 'Registra un nuevo ingreso',
        uso: '/ingreso <monto> <descripción>',
        ejemplo: '/ingreso 100.50 Pago de cliente',
        notas: [
            '• El monto debe ser positivo',
            '• La descripción es obligatoria',
            '• Se actualiza el balance automáticamente'
        ]
    },
    gasto: {
        comando: '/gasto',
        descripcion: 'Registra un nuevo gasto',
        uso: '/gasto <monto> <descripción>',
        ejemplo: '/gasto 50.75 Compra de materiales',
        notas: [
            '• El monto debe ser positivo',
            '• La descripción es obligatoria',
            '• Se descuenta del balance automáticamente'
        ]
    },
    carrera: {
        comando: '/carrera',
        descripcion: 'Gestiona las carreras',
        uso: [
            '/carrera agregar',
            '/carrera completar <monto>'
        ],
        ejemplo: '/carrera completar 25.00',
        notas: [
            '• Agregar: registra nueva carrera',
            '• Completar: finaliza con pago',
            '• El monto se suma al balance'
        ]
    },
    alquileres: {
        comando: '/alquileres',
        descripcion: 'Gestiona los alquileres',
        uso: [
            '/alquileres',
            '/alquiler_nuevo <nombre> <monto>',
            '/alquiler_pago <nombre> <monto>'
        ],
        ejemplo: '/alquiler_nuevo Local 1 500.00',
        notas: [
            '• Lista todos los alquileres activos',
            '• Muestra estado de pagos',
            '• Calcula total mensual'
        ]
    },
    deuda: {
        comando: '/deuda',
        descripcion: 'Registra y gestiona deudas',
        uso: '/deuda <monto> <descripción>',
        ejemplo: '/deuda 1000 Préstamo personal',
        notas: [
            '• Se registra en el sistema de deudas',
            '• Afecta al balance general',
            '• Incluye fecha automática'
        ]
    }
};

const userCommands = (bot, services) => {
    // Comando de registro simplificado
    bot.command('registro', async (ctx) => {
        try {
            const user = await User.findOne({ telegramId: ctx.from.id.toString() });
            
            if (user) {
                return ctx.reply('✅ Ya tienes una cuenta registrada.');
            }

            // Iniciar proceso de registro
            await ctx.reply(`
📝 Registro de Usuario
━━━━━━━━━━━━━━━
Por favor, envía tus datos en este formato:

Nombre Apellido
telefono

Ejemplo:
Juan Pérez
+34612345678
            `);

            // Aquí puedes agregar la lógica para capturar la respuesta
            // usando bot.on('message') para este chat específico

        } catch (error) {
            console.error('Error en registro:', error);
            ctx.reply('❌ Error al iniciar registro. Intenta nuevamente.');
        }
    });

    // Comando de ayuda
    bot.command('ayuda', hasPermission, (ctx) => {
            ctx.reply(`
📱 Comandos Disponibles
━━━━━━━━━━━━━━━

💰 Finanzas:
• /balance - Ver tu saldo actual
• /ingreso <monto> - Registrar ingreso
• /gasto <monto> - Registrar gasto

🎯 Acciones Rápidas:
• /ver - Ver último movimiento
• /total - Ver total del día
• /resumen - Resumen semanal

❓ Ayuda:
• /ayuda - Ver comandos
• /soporte - Pedir ayuda
        `);
    });

    // Comando de balance
    bot.command(['balance', 'saldo'], hasPermission, async (ctx) => {
        try {
            const financeService = services.getService('finance');
            const balance = await financeService.getBalance(ctx.from.id.toString());

            ctx.reply(`
💰 Balance Actual
━━━━━━━━━━━━━━━
📊 Saldo: $${balance.balanceNeto.toFixed(2)}

📝 Últimos movimientos:
${balance.movimientos.slice(-3).map(m => 
    `${m.tipo === 'ingreso' ? '✅' : '❌'} $${m.monto.toFixed(2)} - ${m.descripcion}`
).join('\n')}
            `);
        } catch (error) {
            console.error('Error en comando balance:', error);
            ctx.reply('❌ Error al obtener balance. Contacta a soporte.');
        }
    });

    // Comando de ingreso
    bot.command('ingreso', hasPermission, async (ctx) => {
        const amount = parseFloat(ctx.message.text.split(' ')[1]);
        if (!amount || isNaN(amount)) {
            return ctx.reply(`
📝 Uso correcto:
/ingreso <monto>
Ejemplo: /ingreso 100
            `);
        }

        try {
            const financeService = services.getService('finance');
            const balance = await financeService.registerTransaction(
                ctx.from.id.toString(),
                'ingreso',
                amount,
                'Ingreso registrado'
            );

        ctx.reply(`
✅ Ingreso Registrado
━━━━━━━━━━━━━━━
💰 Monto: $${amount}
📊 Saldo actual: $${balance.balanceNeto.toFixed(2)}
            `);
        } catch (error) {
            console.error('Error registrando ingreso:', error);
            ctx.reply('❌ Error al registrar ingreso. Contacta a soporte.');
        }
    });

    // Comando de gasto
    bot.command('gasto', hasPermission, async (ctx) => {
        const amount = parseFloat(ctx.message.text.split(' ')[1]);
        if (!amount || isNaN(amount)) {
            return ctx.reply(`
📝 Uso correcto:
/gasto <monto>
Ejemplo: /gasto 50
            `);
        }

        try {
            const financeService = services.getService('finance');
            const balance = await financeService.registerTransaction(
                ctx.from.id.toString(),
                'gasto',
                amount,
                'Gasto registrado'
            );

        ctx.reply(`
✅ Gasto Registrado
━━━━━━━━━━━━━━━
💰 Monto: $${amount}
📊 Saldo actual: $${balance.balanceNeto.toFixed(2)}
            `);
        } catch (error) {
            console.error('Error registrando gasto:', error);
            ctx.reply('❌ Error al registrar gasto. Contacta a soporte.');
        }
    });

    // Comando de SOS
    bot.command('sos', hasPermission, async (ctx) => {
        try {
            const notificationService = services.getService('notification');
            // Notificar al administrador
            await notificationService.sendNotification(
                config.bot.rootId,
                `🆘 ¡${ctx.from.first_name} necesita ayuda!`
            );

            ctx.reply(`
🆘 ¡No te preocupes!
Ya avisé a un adulto para que te ayude.
Espera un momento...
            `);
        } catch (error) {
            console.error('Error en SOS:', error);
            ctx.reply('❌ No pude avisar. Busca a un adulto cerca.');
        }
    });

    // Sistema de premios simple
    bot.command('premio', hasPermission, async (ctx) => {
        const premios = [
            '🌟 ¡Estrella dorada!',
            '🎨 ¡Premio al artista!',
            '📚 ¡Premio al estudioso!',
            '🎮 ¡Premio al jugador!',
            '💪 ¡Premio al esfuerzo!'
        ];
        
        ctx.reply(`
🎉 ¡Felicitaciones!
${premios[Math.floor(Math.random() * premios.length)]}

Sigue así para ganar más premios.
        `);
    });

    // Comando de eliminación con backup
    bot.command('eliminar', async (ctx) => {
        const userId = ctx.from.id.toString();
        
        try {
            const user = await User.findOne({ telegramId: userId });
            if (!user) {
                return ctx.reply('❌ No tienes una cuenta registrada.');
            }

            // Crear backup antes de eliminar
            const backup = new Backup({
                userId: userId,
                dataType: 'user',
                data: user.toObject(),
                deletedBy: userId
            });
            await backup.save();

            // Desactivar usuario en lugar de eliminarlo
            user.isActive = false;
            await user.save();

            ctx.reply(`
🗑️ Cuenta Desactivada
━━━━━━━━━━━━━━━
• Se ha creado un backup de seguridad
• Período de recuperación: 7 días
• Usa /restaurar para recuperar tu cuenta

⚠️ Después de 7 días, la cuenta será eliminada permanentemente.
            `);
        } catch (error) {
            console.error('Error al eliminar cuenta:', error);
            ctx.reply('❌ Error al procesar la solicitud.');
        }
    });

    // Comando de restauración
    bot.command('restaurar', async (ctx) => {
        const userId = ctx.from.id.toString();
        
        try {
            const backup = await Backup.findOne({ 
                userId: userId,
                dataType: 'user'
            }).sort({ deletedAt: -1 });

            if (!backup) {
                return ctx.reply('❌ No se encontró backup para restaurar.');
            }

            // Restaurar usuario
            await User.findOneAndUpdate(
                { telegramId: userId },
                { ...backup.data, isActive: true },
                { upsert: true }
            );

            ctx.reply(`
✅ Cuenta Restaurada
━━━━━━━━━━━━━━━
Tu cuenta ha sido restaurada exitosamente.
Usa /perfil para verificar tus datos.
            `);
        } catch (error) {
            console.error('Error al restaurar cuenta:', error);
            ctx.reply('❌ Error al procesar la restauración.');
        }
    });

    // Comando de soporte
    bot.command('soporte', hasPermission, async (ctx) => {
        try {
            const notificationService = services.getService('notification');
            await notificationService.sendNotification(
                config.bot.rootId,
                `🔔 Solicitud de soporte de: ${ctx.from.first_name}\nID: ${ctx.from.id}`
            );

            ctx.reply(`
📞 Solicitud de Soporte
━━━━━━━━━━━━━━━
✅ Tu solicitud ha sido enviada
⏳ Un administrador te contactará pronto
            `);
        } catch (error) {
            console.error('Error en soporte:', error);
            ctx.reply('❌ Error al solicitar soporte. Intenta más tarde.');
        }
    });

    // Comando de resumen
    bot.command('resumen', hasPermission, async (ctx) => {
        try {
            const financeService = services.getService('finance');
            const balance = await financeService.getBalance(ctx.from.id.toString());
            
            const hoy = new Date();
            const inicioSemana = new Date(hoy.setDate(hoy.getDate() - hoy.getDay()));
            
            const movimientosSemana = balance.movimientos.filter(m => 
                new Date(m.fecha) >= inicioSemana
            );

            let ingresos = 0;
            let gastos = 0;
            movimientosSemana.forEach(m => {
                if (m.tipo === 'ingreso') ingresos += m.monto;
                else if (m.tipo === 'gasto') gastos += m.monto;
            });

            ctx.reply(`
📊 Resumen Semanal
━━━━━━━━━━━━━━━
✅ Ingresos: $${ingresos.toFixed(2)}
❌ Gastos: $${gastos.toFixed(2)}
💰 Balance: $${(ingresos - gastos).toFixed(2)}
            `);
        } catch (error) {
            console.error('Error en resumen:', error);
            ctx.reply('❌ Error al generar resumen. Intenta más tarde.');
        }
    });
};

module.exports = userCommands; 