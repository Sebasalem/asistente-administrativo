const Rental = require('../models/Rental');
const { isRoot } = require('../middleware/authMiddleware');

const rentalCommands = (bot) => {
    // Comando para ver estado de alquileres
    bot.command('alquileres', async (ctx) => {
        try {
            const rentals = await Rental.find().sort('nombre');
            const alDia = rentals.filter(r => r.estado === 'al_dia');
            const pendientes = rentals.filter(r => r.estado === 'pendiente');

            let mensaje = `
📊 Estado de Alquileres

✅ Al día:
${alDia.map(r => `
👤 ${r.nombre}
💰 Monto: $${r.monto.toFixed(2)}
📅 Último pago: ${r.ultimoPago ? r.ultimoPago.toLocaleDateString() : 'Nunca'}`).join('\n')}

⚠️ Pendientes:
${pendientes.map(r => `
👤 ${r.nombre}
💰 Monto: $${r.monto.toFixed(2)}
📅 Último pago: ${r.ultimoPago ? r.ultimoPago.toLocaleDateString() : 'Nunca'}`).join('\n')}

💵 Total mensual: $${rentals.reduce((sum, r) => sum + r.monto, 0).toFixed(2)}

Comandos disponibles:
/alquiler_nuevo - Agregar nuevo alquiler
/alquiler_pago - Registrar pago
/alquiler_historial - Ver historial de pagos
            `;

            ctx.reply(mensaje);
        } catch (error) {
            console.error('Error al obtener alquileres:', error);
            ctx.reply('❌ Error al obtener los alquileres.');
        }
    });

    // Comando para agregar nuevo alquiler
    bot.command('alquiler_nuevo', async (ctx) => {
        const args = ctx.message.text.split(' ');
        args.shift(); // Remover el comando
        const [nombre, monto] = [args.slice(0, -1).join(' '), args[args.length - 1]];

        if (!nombre || !monto || isNaN(monto)) {
            return ctx.reply('❌ Uso correcto: /alquiler_nuevo <nombre> <monto>');
        }

        try {
            const rental = new Rental({
                nombre,
                monto: parseFloat(monto)
            });
            await rental.save();

            ctx.reply(`
✅ Alquiler Registrado
━━━━━━━━━━━━━━━
👤 Inquilino: ${nombre}
💰 Monto: $${parseFloat(monto).toFixed(2)}
            `);
        } catch (error) {
            console.error('Error al crear alquiler:', error);
            ctx.reply('❌ Error al registrar el alquiler.');
        }
    });

    // Comando para registrar pago
    bot.command('alquiler_pago', async (ctx) => {
        const args = ctx.message.text.split(' ');
        args.shift(); // Remover el comando
        const [nombre, monto] = [args.slice(0, -1).join(' '), args[args.length - 1]];

        if (!nombre || !monto || isNaN(monto)) {
            return ctx.reply('❌ Uso correcto: /alquiler_pago <nombre> <monto>');
        }

        try {
            const rental = await Rental.findOne({ nombre });
            if (!rental) {
                return ctx.reply('❌ Inquilino no encontrado.');
            }

            rental.ultimoPago = new Date();
            rental.estado = 'al_dia';
            rental.historialPagos.push({
                fecha: new Date(),
                monto: parseFloat(monto),
                descripcion: 'Pago de alquiler'
            });
            await rental.save();

            ctx.reply(`
✅ Pago Registrado
━━━━━━━━━━━━━━━
👤 Inquilino: ${nombre}
💰 Monto: $${parseFloat(monto).toFixed(2)}
📅 Fecha: ${new Date().toLocaleDateString()}
            `);
        } catch (error) {
            console.error('Error al registrar pago:', error);
            ctx.reply('❌ Error al registrar el pago.');
        }
    });

    // Comando para ver historial
    bot.command('alquiler_historial', async (ctx) => {
        const nombre = ctx.message.text.split(' ').slice(1).join(' ');

        if (!nombre) {
            return ctx.reply('❌ Uso correcto: /alquiler_historial <nombre>');
        }

        try {
            const rental = await Rental.findOne({ nombre });
            if (!rental) {
                return ctx.reply('❌ Inquilino no encontrado.');
            }

            const historial = rental.historialPagos.map(p => `
📅 ${p.fecha.toLocaleDateString()}
💰 $${p.monto.toFixed(2)}
📝 ${p.descripcion}`).join('\n');

            ctx.reply(`
📋 Historial de Pagos - ${nombre}
━━━━━━━━━━━━━━━
${historial || 'No hay pagos registrados'}
            `);
        } catch (error) {
            console.error('Error al obtener historial:', error);
            ctx.reply('❌ Error al obtener el historial.');
        }
    });
};

module.exports = rentalCommands; 