const TaxHandler = require('../handlers/taxHandler');
const { isRegistered } = require('../middleware/authMiddleware');

const taxCommands = (bot) => {
    const handler = new TaxHandler(bot);

    // Reportes fiscales
    bot.command('tax_report', isRegistered, (ctx) => handler.generateTaxReport(ctx, 'mensual'));
    bot.command('tax_quarter', isRegistered, (ctx) => handler.generateTaxReport(ctx, 'trimestral'));
    bot.command('tax_year', isRegistered, (ctx) => handler.generateTaxReport(ctx, 'anual'));
};

module.exports = taxCommands; 