const Debtor = require('../models/Debtor');
const { isRoot } = require('../middleware/authMiddleware');

const debtorCommands = (bot) => {
    // Comando para ver deudores
    bot.command('deudores', async (ctx) => {
        try {
            const debtors = await Debtor.find({ estado: 'pendiente' }).sort('fecha');
            
            let mensaje = `
📋 Lista de Deudores:
${debtors.map(d => `
💎 ID: ${d.id}
👤 Nombre: ${d.nombre}
💰 Monto: $${d.monto.toFixed(2)}
📝 Concepto: ${d.concepto}
📅 Fecha: ${d.fecha.toLocaleDateString()}`).join('\n')}

💵 Total Deudas: $${debtors.reduce((sum, d) => sum + d.monto, 0).toFixed(2)}

Para agregar: /deudores <nombre> <monto> <concepto>
Para marcar pagado: /pagado <ID>
            `;

            ctx.reply(mensaje);
        } catch (error) {
            console.error('Error al obtener deudores:', error);
            ctx.reply('❌ Error al obtener la lista de deudores.');
        }
    });

    // Comando para agregar deudor
    bot.command('deudores', async (ctx) => {
        const args = ctx.message.text.split(' ');
        args.shift(); // Remover el comando
        const [nombre, monto, ...conceptoArr] = args;
        const concepto = conceptoArr.join(' ');

        if (!nombre || !monto || !concepto || isNaN(monto)) {
            return ctx.reply('❌ Uso correcto: /deudores <nombre> <monto> <concepto>');
        }

        try {
            // Obtener último ID
            const lastDebtor = await Debtor.findOne().sort('-id');
            const newId = (lastDebtor?.id || 0) + 1;

            const debtor = new Debtor({
                id: newId,
                nombre,
                monto: parseFloat(monto),
                concepto,
                fecha: new Date()
            });
            await debtor.save();

            ctx.reply(`
✅ Deudor Registrado
━━━━━━━━━━━━━━━
🆔 ID: ${newId}
👤 Nombre: ${nombre}
💰 Monto: $${parseFloat(monto).toFixed(2)}
📝 Concepto: ${concepto}
            `);
        } catch (error) {
            console.error('Error al registrar deudor:', error);
            ctx.reply('❌ Error al registrar el deudor.');
        }
    });

    // Comando para marcar como pagado
    bot.command('pagado', async (ctx) => {
        const id = parseInt(ctx.message.text.split(' ')[1]);

        if (!id || isNaN(id)) {
            return ctx.reply('❌ Uso correcto: /pagado <ID>');
        }

        try {
            const debtor = await Debtor.findOneAndUpdate(
                { id },
                { estado: 'pagado' },
                { new: true }
            );

            if (!debtor) {
                return ctx.reply('❌ Deudor no encontrado.');
            }

            ctx.reply(`
✅ Deuda Marcada como Pagada
━━━━━━━━━━━━━━━
👤 Nombre: ${debtor.nombre}
💰 Monto: $${debtor.monto.toFixed(2)}
📝 Concepto: ${debtor.concepto}
            `);
        } catch (error) {
            console.error('Error al marcar como pagado:', error);
            ctx.reply('❌ Error al procesar el pago.');
        }
    });
};

module.exports = debtorCommands; 