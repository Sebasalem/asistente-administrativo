const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const config = require('./config');
const apiRoutes = require('./routes/api');

class Server {
    constructor() {
        this.app = express();
        this.setupMiddleware();
        this.setupRoutes();
        this.setupErrorHandling();
    }

    setupMiddleware() {
        // Básicos
        this.app.use(express.json());
        this.app.use(express.urlencoded({ extended: true }));
        
        // Seguridad
        this.app.use(helmet());
        this.app.use(cors());
        
        // Logging
        if (config.env.nodeEnv === 'development') {
            this.app.use(morgan('dev'));
        }
    }

    setupRoutes() {
        // Ruta de prueba
        this.app.get('/', (req, res) => {
            res.json({ message: 'Servidor funcionando' });
        });

        // Rutas API
        this.app.use('/api', apiRoutes);
    }

    setupErrorHandling() {
        // 404
        this.app.use((req, res) => {
            res.status(404).json({ error: 'Ruta no encontrada' });
        });

        // Error general
        this.app.use((err, req, res, next) => {
            console.error('Error:', err);
            res.status(500).json({
                error: 'Error interno del servidor',
                message: config.env.nodeEnv === 'development' ? err.message : undefined
            });
        });
    }

    start() {
        try {
            const port = config.server.port;
            const host = config.server.host;
            this.server = this.app.listen(port, host, () => {
                console.log(`✅ Servidor API iniciado en ${host}:${port}`);
            });
        } catch (error) {
            console.error('❌ Error iniciando servidor:', error);
            throw error;
        }
    }

    async stop() {
        if (this.server) {
            await new Promise((resolve) => {
                this.server.close(resolve);
            });
            console.log('✅ Servidor detenido correctamente');
        }
    }
}

module.exports = new Server(); 