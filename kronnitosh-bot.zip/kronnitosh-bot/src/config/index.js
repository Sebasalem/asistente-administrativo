require('dotenv').config();

const config = {
    bot: {
        token: process.env.TELEGRAM_BOT_TOKEN,
        rootId: process.env.ROOT_ID,
        admins: (process.env.BOT_ADMINS || '').split(','),
    },
    
    server: {
        port: parseInt(process.env.PORT || '3000'),
        host: process.env.HOST || 'localhost',
        env: process.env.NODE_ENV || 'development',
    },
    
    db: {
        uri: process.env.MONGODB_URI,
        options: {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
            family: 4,
        }
    },

    env: {
        nodeEnv: process.env.NODE_ENV || 'development',
        debug: process.env.DEBUG === 'true',
    }
};

// Validación de configuración crítica
if (!config.bot.token) throw new Error('TELEGRAM_BOT_TOKEN no está configurado');
if (!config.bot.rootId) throw new Error('ROOT_ID no está configurado');
if (!config.db.uri) throw new Error('MONGODB_URI no está configurado');

console.log('✅ Configuración cargada correctamente');

module.exports = config; 