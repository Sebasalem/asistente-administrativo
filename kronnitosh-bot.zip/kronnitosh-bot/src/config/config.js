require('dotenv').config();

const config = {
  mongodb: {
    uri: process.env.MONGODB_URI,
    options: {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
      family: 4,
      directConnection: true
    }
  },
  bot: {
    token: process.env.BOT_TOKEN,
    admins: process.env.BOT_ADMINS ? process.env.BOT_ADMINS.split(',') : []
  },
  environment: process.env.NODE_ENV || 'development',
  debug: process.env.DEBUG === 'true'
};

if (!config.bot.token) {
  throw new Error('BOT_TOKEN no está configurado en el archivo .env');
}

if (!config.mongodb.uri) {
  throw new Error('MONGODB_URI no está configurado en el archivo .env');
}

module.exports = config; 